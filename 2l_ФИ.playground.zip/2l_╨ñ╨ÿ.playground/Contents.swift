//: A Cocoa based Playground to present user interface

import AppKit
import PlaygroundSupport

// Задание 1

func EvenNumber (_ number: Int) {
    if (number % 2 == 0) {
        print("Число четное")
    } else {
        print("Число нечетное")
    }
    
}
EvenNumber(7)

// Задание 2

func NoRemainingBalance (_ number1: Int) -> () {
    var n: Int = number1
    n = n % 3
    if (n == 0) {
        print("Число делится на 3 без остатка")
    } else {
        print("Число не делится на 3 без остатка")
    }
}
NoRemainingBalance(3)

// Задание 3

var array = [Int](1...100)
print(array)

// Задание 4

for (_, value) in array.enumerated() {
    if (value % 2) == 0 || (value % 3) != 0 {
        array.remove(at: array.firstIndex(of: value)!)
    }
}
print("Массив \(array)")
